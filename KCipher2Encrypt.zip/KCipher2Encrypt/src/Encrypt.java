import java.io.*;
import kcipher2.crypto.KCipher2;

class CipherUtils {

    /** �閧���̃o�C�g��(16�^24�^32) */
    public static final int LEN = 16;

    /** �閧�� */
    public static final byte[] KEY = {
        (byte) 0xC3, (byte) 0x84, (byte) 0x57, (byte) 0x88,
        (byte) 0x0B, (byte) 0xDA, (byte) 0x6F, (byte) 0xFD,
        (byte) 0x41, (byte) 0xEE, (byte) 0x05, (byte) 0x45,
        (byte) 0x8A, (byte) 0x02, (byte) 0x6C, (byte) 0x51 };

    /** �����x�N�g�� */
    public static final byte[] IV = {
        (byte) 0xB2, (byte) 0x9B, (byte) 0x34, (byte) 0xEE,
        (byte) 0x66, (byte) 0x0A, (byte) 0xF7, (byte) 0x85,
        (byte) 0xD1, (byte) 0x3F, (byte) 0xF8, (byte) 0xF8,
        (byte) 0xF3, (byte) 0xBA, (byte) 0xC6, (byte) 0x3C };

    
    public static boolean encrypt(String src, String dst ) {

        boolean ret = false;
        if (src.length()==0 || dst.length()==0) {
            return ret;
        }

        KCipher2 k2ctx = new KCipher2();

        // ����������
        try {
            k2ctx.init(KEY, LEN, IV);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            FileInputStream in
                = new FileInputStream(src);  // ���̓t�@�C�����J��
            FileOutputStream out
                = new FileOutputStream(dst); // �o�̓t�@�C�����J��
            
            byte[] buf = new byte[8*1024]; // �o�b�t�@�m��
            
            int read_len;
            while ((read_len = in.read(buf)) != -1) {
                out.write(k2ctx.encrypt(buf, 0, read_len)); // �o��
            }
            in.close();             // ���̓t�@�C�������
            out.close();            // �o�̓t�@�C�������
            ret = true;
        } catch (Exception e) {
            System.err.println(e);  // �G���[���b�Z�[�W�o��
            ret = false;
        }
        
        // �㏈��
        if (k2ctx != null) {
            k2ctx.doFinal();
        }

        return ret;
    }
}

class Encrypt {
    public static void main(String[] args) {

        int args_max = args.length;
        if (args_max <2) {
            System.out.println("exec <src file> <dst file>");
        } else {
            CipherUtils.encrypt(args[0], args[1]);
        }

    }
}
